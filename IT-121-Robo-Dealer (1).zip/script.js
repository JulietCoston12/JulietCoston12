function cards(){
  const value = ["Hearts, -3", "spades," -2, "diamonds," -1, "clubs 0"];
 const cards = document.querySelectorAll(".card");
}
let cards = ["Hearts",-3, "spades", -2, "diamonds", -1, "clubs" 0];
document.getElementById("value"), innerHTML = value.toString();
Math.floor(Math.random() * 52); 
console.log(Hearts); // return array of cards in order
console.log(Spades.lenght); // return number of cards in deck
console.log(diamond.lenght[0]); // retun first card in deck
console.log(suit[clubs.lenght -1]); // return last card in the deck
console.log(cards[math.floor(math.random() * 52)]) // return random card in the deck


